package com.mama.blokir

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("blokir", Context.MODE_PRIVATE)
    fun pin(c: Context): String? = sp(c).getString("pin", null)
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", p).apply()
    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet()) ?: emptySet()
    fun setBlocked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("blocked", HashSet(s)).apply()
}

class MainActivity : Activity() {
    private var unlocked = false
    private lateinit var box: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        sv.addView(box)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onStop() {
        super.onStop()
        unlocked = false
    }

    private fun render() {
        box.removeAllViews()
        when {
            Prefs.pin(this) == null -> pinScreen(true)
            !unlocked -> pinScreen(false)
            else -> mainScreen()
        }
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 24f
        setPadding(0, 0, 0, 24)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun pinScreen(setup: Boolean) {
        box.addView(title(if (setup) "Buat PIN untuk mama" else "Masukkan PIN"))
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN (minimal 4 angka)"
        }
        val btn = Button(this).apply { text = if (setup) "Simpan PIN" else "Buka" }
        btn.setOnClickListener {
            val v = et.text.toString()
            if (setup) {
                if (v.length < 4) {
                    toast("PIN minimal 4 angka")
                    return@setOnClickListener
                }
                Prefs.setPin(this, v)
                unlocked = true
                render()
            } else if (v == Prefs.pin(this)) {
                unlocked = true
                render()
            } else {
                toast("PIN salah")
            }
        }
        box.addView(et)
        box.addView(btn)
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/")
    }

    private fun mainScreen() {
        box.addView(title("Blokir Aplikasi"))
        val on = accessibilityOn()
        box.addView(TextView(this).apply {
            text = if (on) "Pemblokiran AKTIF"
            else "Pemblokiran belum aktif. Ketuk tombol di bawah, pilih \"Blokir Aplikasi\", lalu nyalakan."
            setPadding(0, 0, 0, 16)
        })
        if (!on) {
            box.addView(Button(this).apply {
                text = "Buka pengaturan aksesibilitas"
                setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            })
        }
        box.addView(TextView(this).apply {
            text = "Centang aplikasi yang mau diblokir:"
            setPadding(0, 32, 0, 8)
        })
        val blocked = Prefs.blocked(this).toMutableSet()
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        for ((pkg, label) in apps) {
            box.addView(CheckBox(this).apply {
                text = label
                isChecked = pkg in blocked
                setOnCheckedChangeListener { _, checked ->
                    if (checked) blocked.add(pkg) else blocked.remove(pkg)
                    Prefs.setBlocked(this@MainActivity, blocked)
                }
            })
        }
    }
}
