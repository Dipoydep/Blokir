package com.mama.blokir

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BlockService : AccessibilityService() {
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg !in Prefs.blocked(this)) return
        val now = System.currentTimeMillis()
        if (now - last < 1000) return
        last = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Aplikasi ini diblokir", Toast.LENGTH_LONG).show()
    }

    override fun onInterrupt() {}
}
